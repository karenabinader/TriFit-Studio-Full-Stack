class BookingForm {
  constructor() {
    this.activitySelect = document.getElementById('activity');
    this.subcategorySelect = document.getElementById('subcategory');
    this.availabilityDiv = document.getElementById('availability');
    this.form = document.getElementById('bookingForm');
    this.formMessage = document.getElementById('formMessage');

    this.availability = {
      'mat': 8,
      'reformer': 8,
      'lagree': 8,
      'kids-swim': 5,
      'lap-swim': 1,
      'aqua-fitness': 10,
      'outdoor-tennis': 4,
      'indoor-tennis': 2
    };

    this.bookings = {}; // format: "YYYY-MM-DD HH:MM classType" => count

    this.classTypes = {
      pilates: [
        { value: 'mat', text: 'Mat Pilates' },
        { value: 'reformer', text: 'Reformer Pilates' },
        { value: 'lagree', text: 'Lagree Pilates' }
      ],
      tennis: [
        { value: 'indoor-tennis', text: 'Indoor Tennis' },
        { value: 'outdoor-tennis', text: 'Outdoor Tennis' }
      ],
      swimming: [
        { value: 'lap-swim', text: 'Lap Swimming' },
        { value: 'kids-swim', text: 'Kids\' Swim Lessons' },
        { value: 'aqua-fitness', text: 'Aqua Fitness' }
      ]
    };

    this.addEventListeners();
  }
  async checkWeather(date, city = 'London') {
  const apiKey = 'YOUR_API_KEY_HERE'; // Replace with your real API key
  const url = `https://api.api-ninjas.com/v1/weatherforecast?city=${city}`;

  try {
    const response = await fetch(url, {
      headers: {
        'X-Api-Key': apiKey
      }
    });

    if (!response.ok) throw new Error(`API error: ${response.statusText}`);

    const data = await response.json();

    const forecastDay = data.forecast.find(f => f.day === date);
    if (!forecastDay) return false;

    const condition = forecastDay.conditions.toLowerCase();
    return condition.includes('rain');
  } catch (err) {
    console.error('Weather API failed:', err);
    return false; // Assume clear weather on error
  }
}

  addEventListeners() {
    this.activitySelect.addEventListener('change', () => this.onActivityChange());
    this.subcategorySelect.addEventListener('change', () => this.updateAvailability());
    document.getElementById('date').addEventListener('change', () => this.updateAvailability());
    document.getElementById('time').addEventListener('change', () => this.updateAvailability());
    this.form.addEventListener('submit', (e) => this.onSubmit(e));
  }

  onActivityChange() {
    const selected = this.activitySelect.value;
    this.subcategorySelect.innerHTML = '';
    this.subcategorySelect.disabled = !selected;

    const defaultOption = document.createElement('option');
    defaultOption.value = '';
    defaultOption.textContent = '-- Select a class type --';
    this.subcategorySelect.appendChild(defaultOption);

    if (this.classTypes[selected]) {
      this.classTypes[selected].forEach(opt => {
        const option = document.createElement('option');
        option.value = opt.value;
        option.textContent = opt.text;
        this.subcategorySelect.appendChild(option);
      });
    }
    this.updateAvailability();
  }

  updateAvailability() {
    const classType = this.subcategorySelect.value;
    const date = document.getElementById('date').value;
    const time = document.getElementById('time').value;

    if (!classType || !date || !time) {
      this.availabilityDiv.textContent = 'Available spots: -';
      return;
    }

    const key = `${date} ${time} ${classType}`;
    const booked = this.bookings[key] || 0;
    const max = this.availability[classType] || 0;
    const remaining = max - booked;

    this.availabilityDiv.textContent = `Available spots: ${remaining > 0 ? remaining : 0}`;
  }

async onSubmit(e) {
  e.preventDefault();

  const classType = this.subcategorySelect.value;
  const date = document.getElementById('date').value;
  const time = document.getElementById('time').value;
  const name = document.getElementById('name').value.trim();
  const email = document.getElementById('email').value.trim();

  if (!classType || !date || !time || !name || !email) {
    this.formMessage.textContent = 'Please fill in all fields.';
    this.formMessage.style.color = 'red';
    return;
  }

  const bookingDateTime = new Date(`${date}T${time}`);
  const now = new Date();

  if (bookingDateTime < now) {
    this.formMessage.textContent = 'Invalid date.';
    this.formMessage.style.color = 'red';
    return;
  }

  const bookingDate = new Date(date);
  if (bookingDate.getDay() === 0) {
    this.formMessage.textContent = 'Sorry, no bookings on Sundays.';
    this.formMessage.style.color = 'red';
    return;
  }

  // ☁️ Weather Check for outdoor tennis
  if (classType === 'outdoor-tennis') {
    const isRaining = await this.checkWeather(date);
    if (isRaining) {
      this.formMessage.textContent = 'Cannot book outdoor tennis — rain is forecasted.';
      this.formMessage.style.color = 'red';
      return;
    }
  }

  const key = `${date} ${time} ${classType}`;
  this.bookings[key] = (this.bookings[key] || 0) + 1;

  if (this.bookings[key] > this.availability[classType]) {
    this.formMessage.textContent = 'This class is already full.';
    this.formMessage.style.color = 'red';
    this.bookings[key]--;
    this.updateAvailability();
    return;
  }

  this.formMessage.textContent = 'Booking confirmed!';
  this.formMessage.style.color = 'green';
  setTimeout(() => {
    this.formMessage.textContent = '';
  }, 3000);

  this.form.reset();
  this.subcategorySelect.disabled = true;
  this.updateAvailability();
}
}

// Initialize the booking form logic when DOM is ready
document.addEventListener('DOMContentLoaded', () => {
  new BookingForm();
});